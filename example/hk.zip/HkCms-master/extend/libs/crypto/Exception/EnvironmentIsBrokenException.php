<?php

namespace libs\crypto\Exception;

class EnvironmentIsBrokenException extends \libs\crypto\Exception\CryptoException
{
}
