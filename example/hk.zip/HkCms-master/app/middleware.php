<?php
// 全局中间件定义文件
return [
    // 全局请求缓存
    // \think\middleware\CheckRequestCache::class,
    // Session初始化
     \think\middleware\SessionInit::class,
];
