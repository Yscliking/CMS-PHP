<?php

return [
    // 默认分页一页承载的记录行数
    'default_limit'=>20,
    // 最大分页一页承载的记录行数
    'limit_max'=>100,
];