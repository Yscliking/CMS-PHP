<?php
return [
    // 提示
    "Operation failed"                          => '操作失败',
    "The mailbox interface is down"             => '邮箱接口已关闭',
    'The account has been disabled'             => '账号已被禁用',
    'User not exists'                           => '用户不存在',
    'Please login to operate'                   => '请登录后操作',
    'Token has since expired'                   => 'Token已过期',
    '404 Not found'                             => '页面不存在',
    "Operation succeeded"                       => '操作成功',

    'Email'                                     => '邮箱',
    'Event'                                     => '事件',
    'Keep secret'                               => '保密',
    'Female'                                    => '男',
    'male'                                      => '女',
];