<?php

return [
    'Please input account'=>'请输入账号',
    'Please input password'=>'请输入密码',
    'The account or password is incorrect'=>'账号或密码错误',
    'Too many incorrect accounts or passwords. Please try again later'=>'账号或密码错误次数过多，请稍后再试',
];