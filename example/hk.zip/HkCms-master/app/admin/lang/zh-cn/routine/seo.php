<?php
return [
    // 提示
    'Custom content cannot be empty'   => '自定义内容不能为空',
    'Column rules cannot be empty'   => '栏目规则不能为空',
    'Content rules cannot be empty'   => '内容规则不能为空',
    'The static file storage directory name can only be alphanumeric underscore'   => '静态文件保存目录名称只能是字母数字下划线',

    // 字段
    'URL Config'                                                    => 'URL 配置',
    'URL mode'                                                      => 'URL 模式',
    'Column title format'                                           => '栏目标题格式',
    'Content title format'                                          => '内容标题格式',
    'URL format'                                                    => 'Url 格式',
    'Please change the URL pattern to static generation and try again'  => '请将URL模式改成静态生成后再试',
];