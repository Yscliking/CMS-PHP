<?php
return [
    'Permission rules cannot be empty'                              => '权限规则不能为空',
    'Super administrator cannot operate'                            => '超级管理员不可操作',
    'Cannot choose oneself or one\'s own subordinate as the parent' => '不能选择自己或自己的下级作为父级',
    'Illegal format'                                                => '非法格式',
    'Name'                                                          => '名称',
    'Parent role'                                                   => '父角色',
    'Competence'                                                    => '权限',
    'Remark'                                                        => '备注',
    'Rules'                                                         => '权限',
    'Column authority'                                              => '栏目权限',
    'Nothing'                                                       => '无',
    'Select all'                                                    => '选中全部',
    'Expand All'                                                    => '展开全部',
    'Please select authority node'                                  => '请选择权限菜单',
    'Cannot choose oneself as the parent'                           => '不能选择自己作为父级',
];