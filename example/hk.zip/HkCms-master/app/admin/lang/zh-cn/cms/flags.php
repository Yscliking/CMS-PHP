<?php
return [
    'Name' => '属性值',
    'Weigh'=> '排序',
];