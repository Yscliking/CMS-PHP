<?php
// index应用中间件定义文件
return [
     \app\common\middleware\LoadLangPack::class
];
