<?php
return [
    'Search for `%s` related content' => '搜索“%s”相关的内容',
    'Release date' => '发布时间',
    'Default' => '默认',
    'Pageviews' => '浏览量',
];