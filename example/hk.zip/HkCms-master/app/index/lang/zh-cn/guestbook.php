<?php
return [
    'E-mail format is incorrect'                    => '邮箱格式不正确',
    'Email address cannot be empty'                 => '邮箱地址不能为空',
    'Email function is not enabled'                 => '邮箱功能未开启',
    'SMS plugin not installed'                      => '未安装短信插件',
    'Mobile number cannot be empty'                 => '手机号不能为空',
    'Mobile number format is incorrect'             => '手机号格式不正确',
    'Sent successfully'                             => '发送成功',
    'Sending too frequently, please try again in two hours' => '发送过于频繁，请两小时后再试',
    'Email is not opened, and email notification cannot be used' => '未开启邮箱，无法使用邮箱通知',
];